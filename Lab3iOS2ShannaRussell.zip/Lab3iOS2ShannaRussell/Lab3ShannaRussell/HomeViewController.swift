//
//  ViewController.swift
//  Lab3ShannaRussell
//
//  Created by user214013 on 2/7/22.
//

import UIKit

class HomeViewController: UIViewController {
    
   
    var logoImg: UIImageView?
    var companynameImg: UIImageView?
    var welcomeImg: UIImageView?
    var matchButtonImg: UIImageView?
    var matchbtn: UIButton?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .white
        
        
        logoImg = UIImageView(image: UIImage(named: "group1"))

        view.addSubview(logoImg!)
    
        logoImg?.translatesAutoresizingMaskIntoConstraints = false
        logoImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 0.5).isActive = true
        
        logoImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        logoImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        logoImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
        
        welcomeImg = UIImageView(image: UIImage(named: "welcomeTo"))
        view.addSubview(welcomeImg!)
    
       welcomeImg?.translatesAutoresizingMaskIntoConstraints = false
       welcomeImg?.topAnchor.constraint(equalToSystemSpacingBelow: logoImg!.bottomAnchor, multiplier:0.3).isActive = true
        
        welcomeImg?.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 1.0).isActive = true
        
      
        companynameImg = UIImageView(image: UIImage(named: "perfectMatch"))
        view.addSubview(companynameImg!)
    
        companynameImg?.translatesAutoresizingMaskIntoConstraints = false
        companynameImg?.topAnchor.constraint(equalToSystemSpacingBelow: welcomeImg!.bottomAnchor, multiplier:0.3).isActive = true
        
        companynameImg?.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 1.0).isActive = true
        companynameImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9).isActive = true
                
        matchbtn = UIButton()
        matchbtn?.setBackgroundImage(UIImage(named: "button"), for: .normal)
        self.view.bringSubviewToFront(matchbtn!)
        
        matchbtn?.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(matchbtn!)
        
        //adding a target for our button gesture
       matchbtn?.addTarget(self, action: #selector(gestureFunc), for: .touchUpInside)
        
        matchbtn?.translatesAutoresizingMaskIntoConstraints = false
        
        matchbtn?.topAnchor.constraint(equalToSystemSpacingBelow: companynameImg!.bottomAnchor, multiplier:10.0).isActive = true
        
        matchbtn?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        matchbtn?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
      //  logoImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
    }
    
    @objc func gestureFunc() {
        //MARK: - Button will push us back last VC
        navigationController?.pushViewController(matchPageViewController(), animated: true)
    }

    
}

