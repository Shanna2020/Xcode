//
//  ProfilePageSecond.swift
//  Lab3ShannaRussell
//
//  Created by user214013 on 2/23/22.
//


import UIKit

class ProfilePageSecondViewController: UIViewController {

    var headingImg: UIImageView?
    var BackgroundImg: UIImageView?
    var NameBlockImg: UIImageView?
    var starImg:UIImageView?
    var label: UILabel?
    var secondlabel: UILabel?
    var singleHeartImg: UIImageView?
    var doubleHeartImg: UIImageView?
    var singlelabel: UILabel?
    var doublelabel: UILabel?

    var notificationImg: UIImageView?
    var discoverImg: UIImageView?
    
    var verifybtn:UIButton?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
        self.view.backgroundColor = .white
        
        
        headingImg = UIImageView(image: UIImage(named: "rectangleHeading"))

        view.addSubview(headingImg!)
    
        headingImg?.translatesAutoresizingMaskIntoConstraints = false
        headingImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 3.0).isActive = true
        
        headingImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        headingImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        headingImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
    
        discoverImg = UIImageView(image: UIImage(named: "discoverImg"))

        view.addSubview(discoverImg!)
    
        discoverImg?.translatesAutoresizingMaskIntoConstraints = false
        discoverImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 4.0).isActive = true
        
        discoverImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        discoverImg?.widthAnchor.constraint(equalTo: headingImg!.widthAnchor, multiplier: 0.30).isActive = true
        
        
             
        
        notificationImg = UIImageView(image: UIImage(named: "notification"))

        view.addSubview(notificationImg!)
    
        notificationImg?.translatesAutoresizingMaskIntoConstraints = false
        notificationImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 5.0).isActive = true
    
        notificationImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: discoverImg!.trailingAnchor, multiplier: 4.0).isActive=true
        

        
        
        BackgroundImg = UIImageView(image: UIImage(named: "BackgroundProfile"))

        view.addSubview(BackgroundImg!)
    
        BackgroundImg?.translatesAutoresizingMaskIntoConstraints = false
        BackgroundImg?.topAnchor.constraint(equalToSystemSpacingBelow: headingImg!.bottomAnchor, multiplier: 5.0).isActive = true
        
        BackgroundImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 3.0).isActive=true
        BackgroundImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8).isActive = true
        BackgroundImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
        
        
        
        NameBlockImg = UIImageView(image: UIImage(named: "redrectangle"))

        view.addSubview(NameBlockImg!)
    
        NameBlockImg?.translatesAutoresizingMaskIntoConstraints = false
        NameBlockImg?.topAnchor.constraint(equalToSystemSpacingBelow: BackgroundImg!.bottomAnchor, multiplier: 0.1).isActive = true
        
        NameBlockImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 3.0).isActive=true
      //  NameBlockImg?.trailingAnchor.constraint(equalToSystemSpacingAfter: view.trailingAnchor, multiplier: 2.0).isActive=true
        NameBlockImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8).isActive = true
        NameBlockImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
       
        label = UILabel()
        label?.text = "Alennder, Grace - 24"
        label?.font = UIFont(name: "Verdana", size: 20)
        label?.textColor = .white
        label?.numberOfLines = 0
        label?.textAlignment = .center
        label?.adjustsFontSizeToFitWidth = true
        label?.sizeToFit()
        self.view.addSubview(label!)
        
        //Constraints for label
        label?.translatesAutoresizingMaskIntoConstraints = false
        
        label?.topAnchor.constraint(greaterThanOrEqualToSystemSpacingBelow: NameBlockImg!.topAnchor, multiplier: 0.5).isActive = true
        label?.leadingAnchor.constraint(equalToSystemSpacingAfter: NameBlockImg!.leadingAnchor, multiplier: 2.0).isActive=true
                   
        
        
        secondlabel = UILabel()
        secondlabel?.text = "Markham Road, Ontario, Canada"
        secondlabel?.font = UIFont(name: "Verdana", size: 12)
        secondlabel?.textColor = .white
        secondlabel?.numberOfLines = 0
        secondlabel?.textAlignment = .center
        secondlabel?.adjustsFontSizeToFitWidth = true
        secondlabel?.sizeToFit()
        self.view.addSubview(secondlabel!)
        
        //Constraints for label
        secondlabel?.translatesAutoresizingMaskIntoConstraints = false
        
       secondlabel?.topAnchor.constraint(greaterThanOrEqualToSystemSpacingBelow: label!.bottomAnchor, multiplier: 0.0).isActive = true
        secondlabel?.leadingAnchor.constraint(equalToSystemSpacingAfter: NameBlockImg!.leadingAnchor, multiplier: 2.0).isActive=true
       
      
        
        singleHeartImg = UIImageView(image: UIImage(named: "heartSolid"))

        view.addSubview(singleHeartImg!)
        singleHeartImg?.layer.borderWidth = 1
        singleHeartImg?.layer.masksToBounds = false
        singleHeartImg?.layer.borderColor = UIColor.black.cgColor
        singleHeartImg?.layer.cornerRadius = singleHeartImg!.frame.height/2 //This will change with corners of image and height/2 will make this circle shape
        singleHeartImg?.clipsToBounds = true
    
        singleHeartImg?.translatesAutoresizingMaskIntoConstraints = false
        singleHeartImg?.topAnchor.constraint(equalToSystemSpacingBelow: secondlabel!.bottomAnchor, multiplier: 3.0).isActive = true
        singleHeartImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 5).isActive=true
        
        
        starImg = UIImageView(image: UIImage(named: "star"))
        starImg?.layer.borderWidth = 1
        starImg?.layer.masksToBounds = false
        starImg?.layer.borderColor = UIColor.black.cgColor
        starImg?.layer.cornerRadius = starImg!.frame.height/2 //This will change with corners of image and height/2 will make this circle shape
        starImg?.clipsToBounds = true
        
        view.addSubview(starImg!)
    
        starImg?.translatesAutoresizingMaskIntoConstraints = false
        starImg?.topAnchor.constraint(equalToSystemSpacingBelow: secondlabel!.bottomAnchor, multiplier: 3.0).isActive = true
        starImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: singleHeartImg!.leadingAnchor, multiplier: 10.0).isActive=true
        
      
    
        doubleHeartImg = UIImageView(image: UIImage(named: "brokenHeart"))
        doubleHeartImg?.layer.borderWidth = 1
        doubleHeartImg?.layer.masksToBounds = false
        doubleHeartImg?.layer.borderColor = UIColor.black.cgColor
        doubleHeartImg?.layer.cornerRadius = doubleHeartImg!.frame.height/2 //This will change with corners of image and height/2 will make this circle shape
        doubleHeartImg?.clipsToBounds = true
        
        view.addSubview(doubleHeartImg!)
    
        doubleHeartImg?.translatesAutoresizingMaskIntoConstraints = false
        doubleHeartImg?.topAnchor.constraint(equalToSystemSpacingBelow: secondlabel!.bottomAnchor, multiplier: 3.0).isActive = true
        doubleHeartImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: starImg!.leadingAnchor, multiplier:10.0).isActive=true
      
    
    }

    
   @objc func gestureFunc() {
        //MARK: - Button will push us back last VC
        navigationController?.pushViewController(ProfilePageViewController(), animated: true)
    }
}
