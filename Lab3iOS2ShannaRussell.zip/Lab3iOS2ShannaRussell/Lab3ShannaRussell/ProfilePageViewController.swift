//
//  ProfilePage.swift
//  Lab3ShannaRussell
//
//  Created by user214013 on 2/18/22.
//

import UIKit

class ProfilePageViewController: UIViewController {

    var logoImg: UIImageView?
    var label: UILabel?
    var secondlabel: UILabel?
    var singleHeartImg: UIImageView?
    var doubleHeartImg: UIImageView?
    var singlelabel: UILabel?
    var doublelabel: UILabel?


    
    var verifybtn:UIButton?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
        self.view.backgroundColor = .white
        
        
        logoImg = UIImageView(image: UIImage(named: "fadelogo"))

        view.addSubview(logoImg!)
    
        logoImg?.translatesAutoresizingMaskIntoConstraints = false
        logoImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 0.5).isActive = true
        
        logoImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        logoImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        logoImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
    
        
        label = UILabel()
        label?.text = "Hi Jane"
        label?.font = UIFont(name: "Verdana", size: 15)
        label?.textColor = .black
        label?.numberOfLines = 0
        label?.textAlignment = .center
        label?.adjustsFontSizeToFitWidth = true
        label?.sizeToFit()
        self.view.addSubview(label!)
        
        //Constraints for label
        label?.translatesAutoresizingMaskIntoConstraints = false
        
        label?.topAnchor.constraint(greaterThanOrEqualToSystemSpacingBelow: logoImg!.topAnchor, multiplier: 30.5).isActive = true
       // label?.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 0.5).isActive = true
       label?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0).isActive = true
        label?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
                
        
        
        secondlabel = UILabel()
        secondlabel?.text = "Select Your Status"
        secondlabel?.font = UIFont(name: "Verdana", size: 15)
        secondlabel?.textColor = .black
        secondlabel?.numberOfLines = 0
        secondlabel?.textAlignment = .center
        secondlabel?.adjustsFontSizeToFitWidth = true
        secondlabel?.sizeToFit()
        self.view.addSubview(secondlabel!)
        
        //Constraints for label
        secondlabel?.translatesAutoresizingMaskIntoConstraints = false
        
        secondlabel?.topAnchor.constraint(greaterThanOrEqualToSystemSpacingBelow: label!.bottomAnchor, multiplier: 0.0).isActive = true
       // secondlabel?.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 0.5).isActive = true
        secondlabel?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0).isActive = true
        secondlabel?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
        
        
        
        
        
        
        singleHeartImg = UIImageView(image: UIImage(named: "singleheart"))

        view.addSubview(singleHeartImg!)
    
        singleHeartImg?.translatesAutoresizingMaskIntoConstraints = false
        singleHeartImg?.topAnchor.constraint(equalToSystemSpacingBelow: secondlabel!.bottomAnchor, multiplier: 0.0).isActive = true
        singleHeartImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 1.5).isActive=true
        
      //  logo?.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 1.0).isActive = true
        singleHeartImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.4).isActive = true
        singleHeartImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.15).isActive = true
        
             
        doubleHeartImg = UIImageView(image: UIImage(named: "doubleheart"))

        view.addSubview(doubleHeartImg!)
    
        doubleHeartImg?.translatesAutoresizingMaskIntoConstraints = false
        doubleHeartImg?.topAnchor.constraint(equalToSystemSpacingBelow: secondlabel!.bottomAnchor, multiplier: 0.0).isActive = true
        doubleHeartImg?.trailingAnchor.constraint(equalToSystemSpacingAfter: view.trailingAnchor, multiplier:0.0).isActive=true
        doubleHeartImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.5).isActive = true
        doubleHeartImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.15).isActive = true
        
                
        
        singlelabel = UILabel()
        singlelabel?.text = "Single"
        singlelabel?.font = UIFont(name: "Verdana", size: 8)
        singlelabel?.textColor = .black
        singlelabel?.numberOfLines = 0
        singlelabel?.textAlignment = .center
        singlelabel?.adjustsFontSizeToFitWidth = true
        singlelabel?.sizeToFit()
        self.view.addSubview(singlelabel!)
        
        //Constraints for label
        singlelabel?.translatesAutoresizingMaskIntoConstraints = false
        
        singlelabel?.topAnchor.constraint(greaterThanOrEqualToSystemSpacingBelow: singleHeartImg!.bottomAnchor, multiplier: 0.0).isActive = true
       // secondlabel?.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 0.5).isActive = true
        singlelabel?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.5).isActive = true
       // singlelabel?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
        
        
        
        doublelabel = UILabel()
        doublelabel?.text = "In Relationship"
        doublelabel?.font = UIFont(name: "Verdana", size: 8)
        doublelabel?.textColor = .black
        doublelabel?.numberOfLines = 0
        doublelabel?.textAlignment = .center
        doublelabel?.adjustsFontSizeToFitWidth = true
        doublelabel?.sizeToFit()
        self.view.addSubview(doublelabel!)
        
        //Constraints for label
        doublelabel?.translatesAutoresizingMaskIntoConstraints = false
        
        doublelabel?.topAnchor.constraint(greaterThanOrEqualToSystemSpacingBelow: doubleHeartImg!.bottomAnchor, multiplier: 0.0).isActive = true
        doublelabel?.trailingAnchor.constraint(equalToSystemSpacingAfter: view.trailingAnchor, multiplier:0.5).isActive=true
        doublelabel?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.5).isActive = true
       // doublelabel?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
        
        
        
        verifybtn = UIButton()
        verifybtn?.setBackgroundImage(UIImage(named: "swipingbutton"), for: .normal)
        self.view.bringSubviewToFront(verifybtn!)
        
        verifybtn?.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(verifybtn!)
        
        //adding a target for our button gesture
        verifybtn?.addTarget(self, action: #selector(gestureFunc), for: .touchUpInside)
        
        verifybtn?.translatesAutoresizingMaskIntoConstraints = false
        
        verifybtn?.topAnchor.constraint(equalToSystemSpacingBelow: singlelabel!.bottomAnchor, multiplier:5.0).isActive = true
        verifybtn?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.95).isActive = true
        verifybtn?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1).isActive = true
        verifybtn?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier:0.7).isActive=true
    
    }

    
   @objc func gestureFunc() {
        //MARK: - Button will push us back last VC
        navigationController?.pushViewController(ProfilePageSecondViewController(), animated: true)
    }
}
