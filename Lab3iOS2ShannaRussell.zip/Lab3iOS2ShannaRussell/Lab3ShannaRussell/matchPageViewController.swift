//
//  matchPage.swift
//  Lab3ShannaRussell
//
//  Created by user214013 on 2/11/22.
//

import UIKit

class matchPageViewController: UIViewController {
    
   
    var logoImg: UIImageView?
    var instaMatchImg: UIImageView?
    var fadeBookImg: UIImageView?
    var gobbleButtonImg: UIImageView?
    
    var matchbtn:UIButton?
    var fadebookbtn:UIButton?
    var gobblebtn:UIButton?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
        self.view.backgroundColor = .white
        
        
        logoImg = UIImageView(image: UIImage(named: "group1"))

        view.addSubview(logoImg!)
    
        logoImg?.translatesAutoresizingMaskIntoConstraints = false
        logoImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 0.5).isActive = true
        
        logoImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        logoImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        logoImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
        
        
        
        fadebookbtn = UIButton()
        fadebookbtn?.setBackgroundImage(UIImage(named: "fadebookbtn"), for: .normal)
        self.view.bringSubviewToFront(fadebookbtn!)
        
        fadebookbtn?.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(fadebookbtn!)
        
        //adding a target for our button gesture
        fadebookbtn?.addTarget(self, action: #selector(gestureFunc), for: .touchUpInside)
        
        fadebookbtn?.translatesAutoresizingMaskIntoConstraints = false
        
        fadebookbtn?.topAnchor.constraint(equalToSystemSpacingBelow: logoImg!.bottomAnchor, multiplier:3.0).isActive = true
        fadebookbtn!.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        fadebookbtn?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        
        
        
        gobblebtn = UIButton()
        gobblebtn?.setBackgroundImage(UIImage(named: "gobblebutton"), for: .normal)
        self.view.bringSubviewToFront(gobblebtn!)
        
        gobblebtn?.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(gobblebtn!)
        
        //adding a target for our button gesture
        gobblebtn?.addTarget(self, action: #selector(gestureFunc), for: .touchUpInside)
        
        gobblebtn?.translatesAutoresizingMaskIntoConstraints = false
        
        gobblebtn?.topAnchor.constraint(equalToSystemSpacingBelow: fadebookbtn!.bottomAnchor, multiplier:3.0).isActive = true
        gobblebtn!.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        gobblebtn?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        
        matchbtn = UIButton()
        matchbtn?.setBackgroundImage(UIImage(named: "InstaMatchbutton"), for: .normal)
        self.view.bringSubviewToFront(matchbtn!)
        
        matchbtn?.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(matchbtn!)
        
        //adding a target for our button gesture
       matchbtn?.addTarget(self, action: #selector(gestureFunc), for: .touchUpInside)
        
        matchbtn?.translatesAutoresizingMaskIntoConstraints = false
        
        matchbtn?.topAnchor.constraint(equalToSystemSpacingBelow: gobblebtn!.bottomAnchor, multiplier:3.0).isActive = true
        matchbtn!.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        matchbtn?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
    }

    
   @objc func gestureFunc() {
        //MARK: - Button will push us back last VC
        navigationController?.pushViewController(matchSecondPageViewController(), animated: true)
    }

}

