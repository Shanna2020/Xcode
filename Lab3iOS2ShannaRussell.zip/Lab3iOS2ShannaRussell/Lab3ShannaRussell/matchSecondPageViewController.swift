//
//  matchSecondPageViewController.swift
//  Lab3ShannaRussell
//
//  Created by user214013 on 2/11/22.
//

import UIKit

class matchSecondPageViewController: UIViewController {

    var logoImg: UIImageView?
  
    var mobileButtonImg: UIImageView?
    
    var verifybtn:UIButton?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
        self.view.backgroundColor = .white
        
        
        logoImg = UIImageView(image: UIImage(named: "group1"))

        view.addSubview(logoImg!)
    
        logoImg?.translatesAutoresizingMaskIntoConstraints = false
        logoImg?.topAnchor.constraint(equalToSystemSpacingBelow: view.topAnchor, multiplier: 0.5).isActive = true
        
        logoImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
        logoImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        logoImg?.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5).isActive = true
                
        
        
        mobileButtonImg = UIImageView(image: UIImage(named: "pinkrectangle"))

        view.addSubview(mobileButtonImg!)
    
        mobileButtonImg?.translatesAutoresizingMaskIntoConstraints = false
        mobileButtonImg?.topAnchor.constraint(equalToSystemSpacingBelow: logoImg!.bottomAnchor, multiplier: 0.5).isActive = true
        
        mobileButtonImg?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        mobileButtonImg?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true

             
        verifybtn = UIButton()
        verifybtn?.setBackgroundImage(UIImage(named: "verifybutton"), for: .normal)
        self.view.bringSubviewToFront(verifybtn!)
        
        verifybtn?.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(verifybtn!)
        
        //adding a target for our button gesture
        verifybtn?.addTarget(self, action: #selector(gestureFunc), for: .touchUpInside)
        
        verifybtn?.translatesAutoresizingMaskIntoConstraints = false
        
        verifybtn?.topAnchor.constraint(equalToSystemSpacingBelow: mobileButtonImg!.bottomAnchor, multiplier:5.0).isActive = true
        verifybtn?.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.90).isActive = true
        verifybtn?.leadingAnchor.constraint(equalToSystemSpacingAfter: view.leadingAnchor, multiplier: 2.0).isActive=true
    
    }

    
   @objc func gestureFunc() {
        //MARK: - Button will push us back last VC
        navigationController?.pushViewController(ProfilePageViewController(), animated: true)
    }
}
