//
//  AddRemindVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/8/22.
//

import UIKit

protocol AddingTaskDelegateProtocol {
    func controllerDidCompleteAddTaskDelegate(task: Task)//function to add image
    func controllerDidCancelAddTaskDelegate()//function to cancel image
}



class AddRemindVC: UIViewController{

    public var taskDelegate: AddingTaskDelegateProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        emojiAnimation()
        animateImg()

        
    }
    
    
    
    @IBOutlet weak var taskNameText: UITextField!
    
    @IBOutlet weak var smileEmoji: UIButton!
    
    @IBOutlet weak var loveEmoji: UIButton!
    @IBOutlet weak var straightEmoji: UIButton!
    
    @IBOutlet weak var sadEmoji: UIButton!
    
    
    @IBAction func AddReminderAction(_ sender: Any) {
        
        if let name = taskNameText.text{
                
                if !name.isEmpty{
                    let newTask = Task(n:name,i: "todoOrange" )
                    taskDelegate?.controllerDidCompleteAddTaskDelegate(task: newTask)
                    
                    dismiss(animated: true, completion:nil)
                }
            }
        }

    func emojiAnimation() {
    
        
        UIView.animate(withDuration: 5.0,
                       delay: 0,
                       options: .curveEaseInOut,
                       animations: {self.smileEmoji!.frame.size.width+=10}, completion:nil)
       
       UIView.animate(withDuration: 5.0,
                       delay: 0,
                        options: .allowAnimatedContent,
                        animations: {self.loveEmoji!.center.x=self.view.frame.width/2}, completion:nil)
       
    
        UIView.animate(withDuration: 4.0,
                       delay: 0,
                       options: .allowAnimatedContent,
                       animations: {self.straightEmoji!.center.y=self.view.frame.height/2}, completion:nil)
        
        
    }
    func animateImg() {

    let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 1
           animation.repeatCount = 2
           animation.autoreverses = true
           animation.fromValue = NSValue(cgPoint: CGPoint(x:  sadEmoji!.center.x - 150, y:  sadEmoji!.center.y))
           animation.toValue = NSValue(cgPoint: CGPoint(x:  sadEmoji!.center.x + 150, y:  sadEmoji!.center.y))
        sadEmoji!.layer.add(animation, forKey: "position")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
