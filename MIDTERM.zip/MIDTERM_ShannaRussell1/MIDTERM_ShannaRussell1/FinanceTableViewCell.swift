//
//  FinanceTableVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/8/22.
//

import UIKit

class FinanceTableViewCell: UITableViewCell {

    @IBOutlet weak var financeimage: UIImageView!
    
    
    @IBOutlet weak var Financename: UILabel!
    
    
    @IBOutlet weak var financedetail: UILabel!
    
    
    @IBOutlet weak var financevalue: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
