//
//  FinanceVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/7/22.
//

import UIKit

class FinanceVC: UIViewController ,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var financeTable: UITableView!
    
    var financeManager = FinanceManager()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (financeManager.getAllfinances().count)
        
    }
    ///////////////////////////////////////height///////////////////////////////////////////////////////////
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell")as! FinanceTableViewCell
        
        cell.Financename?.text=financeManager.getAllfinances()[indexPath.row].name
        
        cell.financedetail?.text=financeManager.getAllfinances()[indexPath.row].detail
        
        cell.financevalue?.text=financeManager.getAllfinances()[indexPath.row].value
        
        cell.financeimage?.image=financeManager.getAllfinances()[indexPath.row].financeImage
        
      //  cell.todoImg?.image=taskManager.getAlltasks()[indexPath.row].todoImage
               
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
