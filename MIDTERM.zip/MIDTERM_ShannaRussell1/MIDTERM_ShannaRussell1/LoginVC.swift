//
//  LoginVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/5/22.
//

import UIKit

class LoginVC: UIViewController {
    
    @IBOutlet weak var googleimg: UIImageView!
    
    @IBOutlet weak var signUpbtn: UIButton!
    @IBOutlet weak var facebooImg: UIImageView!
    @IBOutlet weak var forgetpasswordImg: UIImageView!
    @IBOutlet weak var usernamelbl: UITextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var passwordlbl: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        let eyeImg = UIImage.init(named: "eyeIcon")
        
        
        addrightImageTo(txtField: passwordlbl, andImage: eyeImg!)
        // Do any additional setup after loading the view.
  
     
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
       loginAnimation()
        
    }
    func addrightImageTo(txtField: UITextField, andImage img: UIImage){
        let rightImageView = UIImageView(frame: CGRect(x:0.0, y:0.0, width: img.size.width,  height: img.size.height))
        
        rightImageView.image = img
        rightImageView.contentMode = .scaleAspectFit
        txtField.rightView = rightImageView
        txtField.rightViewMode = .always
    }

    func loginAnimation() {
   
       
        UIView.animate(withDuration: 2.0,
                       delay: 1,
                       animations: {
            self.loginBtn!.alpha = 0.5
            self.loginBtn!.backgroundColor=UIColor.systemPink
            self.loginBtn!.alpha = 1
        },
completion:nil)
        
        
        UIView.animate(withDuration: 5.0,
                       delay: 0,
                       usingSpringWithDamping: 0.0,
                       initialSpringVelocity: 0.50,
                       options: .allowAnimatedContent,
                       animations: {
            self.usernamelbl!.center.x=self.view.frame.width/2
            self.passwordlbl!.center.x=self.view.frame.width/2
            
        }, completion:nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
