//
//  Finance.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/8/22.
//


import Foundation
import UIKit

class Finance{
    var name:String
    var detail:String
    var value:String
    var financeImage: UIImage!
    
        
    init(n:String, d: String, v:String, i:String)
    {
        name=n
        detail=d
        value=v
        self.financeImage=UIImage.init(named:i)
    }
       
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
       
    }
