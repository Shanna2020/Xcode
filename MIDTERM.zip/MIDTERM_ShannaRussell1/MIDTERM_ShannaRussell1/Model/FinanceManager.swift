//
//  FinanceManager.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/8/22.
//

import Foundation

class FinanceManager{
 var finance = [Finance]()

init(){
    finance.append(Finance(n: "Jane Doe", d:"Incoming Payment |10.01.2021",v:"+10.00E", i:"FinanceArrDown"))
    finance.append(Finance(n: "Amazon", d:"Outgoing Payment |10.01.2021",v:"-25.00E", i:"FinanceArrUp"))
    finance.append(Finance(n: "likea", d:"Incoming Payment |10.01.2021",v:"-150.00E", i:"FinanceArrUp"))
    finance.append(Finance(n: "Mc Donalds NYC", d:"Incoming Payment |10.01.2021",v:"-15.00E", i:"FinanceArrUp"))
    }



func getAllfinances()->[Finance]{

return finance}

}
