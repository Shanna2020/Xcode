//
//  Task.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/8/22.
//

import Foundation
import UIKit

class Task{
    var name:String
    var todoImage: UIImage!
    
        
    init(n:String, i: String)
    {
        name=n
     
        self.todoImage=UIImage.init(named:i)
    }
       
        
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
       
    }
