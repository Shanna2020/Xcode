//
//  TaskManager.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/8/22.
//

import Foundation
class TaskManager{
 var tasks = [Task]()

init(){
    tasks.append(Task(n: "Daily Meeting", i:"todoOrange"))
    tasks.append(Task(n: "Complete Prototype", i:"todotick"))
    tasks.append(Task(n: "Find People forthe user test", i:"todoOrange"))
    tasks.append(Task(n: "Buy cookie for kids", i:"todoBlue"))
    tasks.append(Task(n: "pay electricity bill", i:"todoOrange"))
}

func addNewTask(newTask: Task){

tasks.append(newTask)

}

func getAlltasks()->[Task]{

return tasks}

}
