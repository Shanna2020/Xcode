//
//  NotificationVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/7/22.
//

import UIKit

class NotificationVC: UIViewController {

    
    @IBOutlet weak var notificationImg: UIImageView!
    @IBOutlet weak var notificationIcon: UIImageView!
    
    @IBAction func NotificationAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        animateImg()

        notificationAnimation()
    }
    func notificationAnimation() {
        UIView.animate(withDuration: 1.0,
                   delay: 1.0,
                   options: [.transitionCrossDissolve, .repeat],
    animations: {
        self.notificationIcon!.layer.opacity=1.0
       // self.instructlabel!.textColor=UIColor.systemPink
        self.notificationIcon!.layer.opacity=0.5
        
     })
        
      
    print("Icon Animation!")
   
}
    
    func animateImg() {

    let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 1
           animation.repeatCount = 2
           animation.autoreverses = true
           animation.fromValue = NSValue(cgPoint: CGPoint(x:  notificationImg!.center.x - 150, y:  notificationImg!.center.y))
           animation.toValue = NSValue(cgPoint: CGPoint(x:  notificationImg!.center.x + 150, y:  notificationImg!.center.y))
        notificationImg!.layer.add(animation, forKey: "position")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
