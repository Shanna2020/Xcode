//
//  SMSConfirmationVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/5/22.
//

import UIKit

class SMSConfirmationVC: UIViewController {

    @IBOutlet weak var firstText: UITextField!
    @IBOutlet weak var backbtn: UIImageView!
   

    @IBAction func keypadAction(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        firstText.keyboardType=UIKeyboardType.numberPad
        firstText.becomeFirstResponder()
        // Do any additional setup after loading the view.
    }
 
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
