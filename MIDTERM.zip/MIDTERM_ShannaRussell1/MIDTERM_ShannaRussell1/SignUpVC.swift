//
//  SignUpVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/6/22.
//

import UIKit

class SignUpVC: UIViewController {

    @IBOutlet weak var SignUplbl: UILabel!
    
    
    @IBOutlet weak var emailtxt: UITextField!
  
    @IBAction func signUpAction(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var usernametxt: UITextField!
    
    @IBOutlet weak var passwordtxt: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        passwordtxt?.centerXAnchor.constraint(greaterThanOrEqualToSystemSpacingAfter: view.centerXAnchor, multiplier: 0.5).isActive = true

        let eyeImg = UIImage.init(named: "eyeIcon")
        let orangeTick = UIImage.init(named: "orangeTickImg")
        
        
        addrightImageTo(txtField: passwordtxt, andImage: eyeImg!)
        addrightImageTo(txtField: usernametxt, andImage: orangeTick!)

        addrightImageTo(txtField: emailtxt, andImage: orangeTick!)

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
       loginSignUp()
        
    }
    func addrightImageTo(txtField: UITextField, andImage img: UIImage){
        let rightImageView = UIImageView(frame: CGRect(x:0.0, y:0.0, width: img.size.width,  height: img.size.height))
        
        rightImageView.image = img
        rightImageView.contentMode = .scaleAspectFit
        txtField.rightView = rightImageView
        txtField.rightViewMode = .always
    }

    func loginSignUp() {
   
        
        UIView.animate(withDuration: 5.0,
                       delay: 1,
                       usingSpringWithDamping: 1.0,
                       initialSpringVelocity: 1.0,
                       options: .allowAnimatedContent,
                       animations: {
            self.passwordtxt!.center.x=self.view.frame.width/2
            self.usernametxt!.center.x=self.view.frame.width/2
            
        }, completion:nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
