//
//  ToDoVC.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/7/22.
//

import UIKit

class ToDoVC: UIViewController ,UITableViewDelegate,UITableViewDataSource,AddingTaskDelegateProtocol{
    
    var taskManager = TaskManager()
    var tasks =  [Task]()

    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var search: UIButton!
    @IBOutlet weak var todoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        todoTableView.separatorStyle = .none
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
       TodoAnimation()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (taskManager.getAlltasks().count)
        
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell")as! TodoCustomTableViewCell
        
        cell.todolbl?.text=taskManager.getAlltasks()[indexPath.row].name
        
        cell.todoImg?.image=taskManager.getAlltasks()[indexPath.row].todoImage
        
        return cell
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
     
    }
    ///////////////////////////////////////height///////////////////////////////////////////////////////////
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Today"
    }
    ////////////////////////////Completed task of adding image///////////////////////////////////////////////////////////////////
    
    func controllerDidCompleteAddTaskDelegate(task: Task) {
        taskManager.addNewTask(newTask: task)
        todoTableView.reloadData()
        
    }
    
    
    //Cancel Task of Adding Image///////////////////////////
    func controllerDidCancelAddTaskDelegate() {
        dismiss(animated: true, completion: nil)

    }
    
    /////////////////prepare /segue////////////////////////////////////////////////////////////////
    override func prepare(for segue:UIStoryboardSegue, sender: Any?){
        
        let addTaskVC=segue.destination as! AddRemindVC
        addTaskVC.taskDelegate = self
        
    }
    
    
    func TodoAnimation() {
     
        
        UIView.animate(withDuration: 1.0,
                       delay: 1.0,
                       options: .repeat,
                       animations: {
           
            
           self.search!.transform = CGAffineTransform(scaleX: 1.0, y:2.0)
            
             self.search!.transform = CGAffineTransform.identity
        },
                       completion: { finished in
                        print("Logo Animation!")
                              
        })
    
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
