//
//  ViewController.swift
//  MIDTERM_ShannaRussell1
//
//  Created by user214013 on 3/5/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var Logo: UIButton!
    
 /////////////////////////////////////////////////////////////
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // Do any additional setup after loading the view.
        animateLogo();
    
    }

    
    
    /////////////////////////////////////////////////////////////////
    
    
    func animateLogo() {
     
        
        UIView.animate(withDuration: 1.0,
                       delay: 1.0,
                       options: [.transitionCurlDown],
                       animations: {
           
            self.Logo!.transform = CGAffineTransform(rotationAngle: .pi)
           self.Logo!.transform = CGAffineTransform(scaleX: 2.0, y:5.0)
            
          self.Logo!.center = CGPoint(x: self.view.frame.width + 75, y: 250)
            self.Logo!.transform = CGAffineTransform.identity
        },
                       completion: { finished in
                        print("Logo Animation!")
                              
        })
        
      
     /* UIView.animate(withDuration: 6.0,
                     delay: 1.0,
                   //  options: [.transitionCurlDown, .transitionCurlDown],
                     animations: {
          self.Logo!.transform = CGAffineTransform(scaleX: 0.2, y:0.5)
          self.Logo!.transform = CGAffineTransform.identity      //    self.verifybtn!.center = CGPoint(x: self.view.frame.width + 75, y: 250)
    },          completion: { finished in
                      print("verify Animation!")
                    
      })*/
        
        

}


   
}
